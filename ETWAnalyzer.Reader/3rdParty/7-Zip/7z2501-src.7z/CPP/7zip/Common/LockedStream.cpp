// LockedStream.cpp

#include "StdAfx.h"
