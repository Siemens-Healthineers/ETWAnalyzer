#define IDD_PROGRESS  97

#define IDC_PROGRESS1  100
