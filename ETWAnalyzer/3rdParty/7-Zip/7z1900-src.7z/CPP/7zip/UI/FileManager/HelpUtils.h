// HelpUtils.h

#ifndef __HELP_UTILS_H
#define __HELP_UTILS_H

#include "../../../Common/MyString.h"

void ShowHelpWindow(LPCSTR topicFile);

#endif
