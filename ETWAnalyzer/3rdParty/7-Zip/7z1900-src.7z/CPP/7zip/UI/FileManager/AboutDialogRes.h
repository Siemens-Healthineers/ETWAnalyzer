#define IDD_ABOUT  2900

#define IDT_ABOUT_INFO  2901

#define IDI_LOGO             100
#define IDT_ABOUT_VERSION    101
#define IDT_ABOUT_DATE       102
#define IDB_ABOUT_HOMEPAGE   110
