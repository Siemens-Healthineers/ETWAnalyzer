// Sha512Prepare.cpp

#include "StdAfx.h"

#include "../../C/Sha512.h"

static struct CSha512Prepare { CSha512Prepare() { Sha512Prepare(); } } g_Sha512Prepare;
