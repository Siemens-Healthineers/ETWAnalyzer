// Common/C_FileIO.cpp

#include "StdAfx.h"
